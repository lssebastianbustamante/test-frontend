$items = array(
  array(
    'id': '10001',
    'imageSrc': 'https://via.placeholder.com/289x419/FF0000/FFFFFF/?text=Product%201',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/FF0000/FFFFFF/?text=Product%201',
    'name': 'Producto Gris para Test 1',
    'listPrice': '2999.00',
    'bestPrice': '1999.00',
    'fees': '12'
  ),
  array(
    'id': '10002',
    'imageSrc': 'https://via.placeholder.com/289x419/0000FF/808080/?text=Product%202',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/0000FF/808080/?text=Product%202',
    'name': 'Producto Gris para Test 2',
    'listPrice': '3999.00',
    'bestPrice': '2999.00',
    'fees': '12'
  ),
  array(
    'id': '10003',
    'imageSrc': 'https://via.placeholder.com/289x419/000000/FFFFFF/?text=Product%203',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/000000/FFFFFF/?text=Product%203',
    'name': 'Producto Gris para Test 3',
    'listPrice': '1500.00',
    'bestPrice': ''1000.00',
    'fees': '12'
  ),
  array(
    'id': '10004',
    'imageSrc': 'https://via.placeholder.com/289x419/00FF00/000000/?text=Product%204',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/00FF00/000000/?text=Product%204',
    'name': 'Producto Gris para Test 4',
    'listPrice': '2999.99',
    'bestPrice': '1999.99',
    'fees': '12'
  ),
  array(
    'id': '10005',
    'imageSrc': 'https://via.placeholder.com/289x419/0000DD/FFFFFF/?text=Product%205',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/0000DD/FFFFFF/?text=Product%205',
    'name': 'Producto Gris para Test 5',
    'listPrice': '785.88',
    'bestPrice': '555.55',
    'fees': '12'
  ),
  array(
    'id': '10006',
    'imageSrc': 'https://via.placeholder.com/289x419/CCDDCC/000000/?text=Product%206',
    'imageSrcMobile': 'https://via.placeholder.com/328x480/CCDDCC/000000/?text=Product%206',
    'name': 'Producto Gris para Test 6',
    'listPrice': '6999.88',
    'bestPrice': '4999.88',
    'fees': '12'
  )
)